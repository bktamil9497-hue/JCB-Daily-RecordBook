package com.example.jcbrecordbook;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText date, place, location, start, close, rate, dieselL, dieselAmt, bata, advance, food, salary, notes;
    TextView hoursOut, amountOut, balanceOut, listOut;
    String photoUri = "";
    SharedPreferences prefs;
    LinearLayout root;
    static final String KEY = "entries";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("jcb_book", MODE_PRIVATE);
        buildUI();
        calculate();
        refreshList();
    }

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(2), dp(7), dp(2), dp(5)); return t;
    }
    EditText input(String hint, String value, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(15);
        e.setHint(hint); e.setInputType(type); e.setText(value == null ? "" : value);
        e.setPadding(dp(10), dp(7), dp(10), dp(7));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.LTGRAY));
        return e;
    }
    void addField(String label, EditText e) { root.addView(text(label, 13, Color.DKGRAY)); root.addView(e, new LinearLayout.LayoutParams(-1, dp(48))); }
    Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(249,185,0)));
        return b;
    }
    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16), dp(12), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(247,249,252));
        scroll.addView(root); setContentView(scroll);
        TextView title = text("🚜 JCB Daily Record Book", 23, Color.WHITE);
        title.setPadding(dp(14), dp(18), dp(14), dp(18));
        title.setBackgroundColor(Color.rgb(7,52,90)); root.addView(title);
        root.addView(text("புதிய வேலை பதிவு / New Work Entry", 18, Color.rgb(7,52,90)));

        date = input("DD-MM-YYYY", new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date()), 1);
        date.setFocusable(false);
        date.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, y, m, d) -> date.setText(String.format(Locale.getDefault(), "%02d-%02d-%04d", d, m+1, y)),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        addField("Date / தேதி", date);
        place = input("Customer or work name", "", 1); addField("Name / வேலை பெயர்", place);
        location = input("Work location", "", 1); addField("Location / இடம்", location);
        start = input("e.g. 1425.9", "", 8194); addField("Starting Reading", start);
        close = input("e.g. 1434.3", "", 8194); addField("Closing Reading", close);
        rate = input("Hourly rate for this job (₹)", "", 8194); addField("Rate per hour (₹)", rate);
        hoursOut = text("Total Hours: 0.00", 16, Color.rgb(7,52,90)); root.addView(hoursOut);
        amountOut = text("Total Amount: ₹0.00", 16, Color.rgb(7,52,90)); root.addView(amountOut);
        root.addView(text("Other expenses / பிற செலவுகள்", 17, Color.rgb(7,52,90)));
        dieselL = input("Diesel litres", "0", 8194); addField("Diesel Liter", dieselL);
        dieselAmt = input("Diesel amount (₹)", "0", 8194); addField("Diesel Amount (₹)", dieselAmt);
        bata = input("Driver bata (₹)", "0", 8194); addField("Driver Bata (₹)", bata);
        advance = input("Advance (₹)", "0", 8194); addField("Advance (₹)", advance);
        food = input("Food (₹)", "0", 8194); addField("Food (₹)", food);
        salary = input("Salary (₹)", "0", 8194); addField("Salary / other payment (₹)", salary);
        notes = input("Optional notes", "", 1); addField("Notes / கூடுதல் விவரம்", notes);
        balanceOut = text("Balance: ₹0.00", 18, Color.rgb(0,110,70)); root.addView(balanceOut);

        TextView photoHint = text("Photo attachment: use the phone camera/gallery separately for now; photo picker can be added next.", 12, Color.GRAY);
        root.addView(photoHint);
        Button calc = button("Calculate"); root.addView(calc); calc.setOnClickListener(v -> calculate());
        Button save = button("Save Entry"); root.addView(save); save.setOnClickListener(v -> saveEntry());
        Button report = button("Monthly Summary"); root.addView(report); report.setOnClickListener(v -> showSummary());
        Button export = button("Export / Share CSV"); root.addView(export); export.setOnClickListener(v -> exportCsv());
        root.addView(text("Saved Records", 19, Color.rgb(7,52,90)));
        listOut = text("", 13, Color.DKGRAY); root.addView(listOut);
        View.OnFocusChangeListener listener = (v, has) -> { if (!has) calculate(); };
        for (EditText e : new EditText[]{start, close, rate, dieselAmt, bata, advance, food, salary}) e.setOnFocusChangeListener(listener);
    }
    double val(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch(Exception ex) { return 0; } }
    double hours() { return Math.max(0, val(close) - val(start)); }
    double amount() { return hours() * val(rate); }
    double balance() { return amount() - val(dieselAmt) - val(bata) - val(advance) - val(food) - val(salary); }
    String money(double v) { return String.format(Locale.getDefault(), "₹%,.2f", v); }
    void calculate() {
        if (hoursOut == null) return;
        hoursOut.setText(String.format(Locale.getDefault(), "Total Hours: %.2f", hours()));
        amountOut.setText("Total Amount: " + money(amount()));
        balanceOut.setText("Balance: " + money(balance()));
    }
    JSONArray entries() {
        try { return new JSONArray(prefs.getString(KEY, "[]")); } catch(Exception e) { return new JSONArray(); }
    }
    void saveEntry() {
        if (start.getText().toString().trim().isEmpty() || close.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Starting and Closing readings are required", Toast.LENGTH_LONG).show(); return;
        }
        try {
            JSONObject o = new JSONObject();
            o.put("date", date.getText().toString()); o.put("place", place.getText().toString());
            o.put("location", location.getText().toString()); o.put("start", val(start)); o.put("close", val(close));
            o.put("hours", hours()); o.put("rate", val(rate)); o.put("amount", amount());
            o.put("dieselL", val(dieselL)); o.put("dieselAmt", val(dieselAmt)); o.put("bata", val(bata));
            o.put("advance", val(advance)); o.put("food", val(food)); o.put("salary", val(salary));
            o.put("balance", balance()); o.put("notes", notes.getText().toString());
            JSONArray a = entries(); a.put(o); prefs.edit().putString(KEY, a.toString()).apply();
            Toast.makeText(this, "Entry saved on this phone", Toast.LENGTH_SHORT).show();
            refreshList();
        } catch(Exception e) { Toast.makeText(this, "Could not save entry", Toast.LENGTH_LONG).show(); }
    }
    void refreshList() {
        if (listOut == null) return;
        JSONArray a = entries(); StringBuilder s = new StringBuilder();
        for(int i=a.length()-1; i>=0; i--) {
            JSONObject o = a.optJSONObject(i); if(o == null) continue;
            s.append(o.optString("date")).append(" • ").append(o.optString("place")).append("\n")
             .append(String.format(Locale.getDefault(), "%.2f hrs • %s • Balance %s",
                o.optDouble("hours"), money(o.optDouble("amount")), money(o.optDouble("balance")))).append("\n\n");
        }
        if(s.length()==0) s.append("No records saved yet.");
        listOut.setText(s.toString());
    }
    void showSummary() {
        JSONArray a = entries(); double hrs=0, amount=0, balance=0; String month = new SimpleDateFormat("MM-yyyy", Locale.getDefault()).format(new Date());
        for(int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o==null) continue;
            if(o.optString("date").endsWith(month)) { hrs+=o.optDouble("hours"); amount+=o.optDouble("amount"); balance+=o.optDouble("balance"); }
        }
        new android.app.AlertDialog.Builder(this).setTitle("Monthly Summary • "+month)
            .setMessage(String.format(Locale.getDefault(), "Total hours: %.2f\nTotal amount: %s\nTotal balance: %s", hrs, money(amount), money(balance)))
            .setPositiveButton("OK", null).show();
    }
    void exportCsv() {
        JSONArray a = entries(); StringBuilder csv = new StringBuilder("Date,Name,Location,Starting,Closing,Hours,Rate,Amount,DieselLitres,DieselAmount,DriverBata,Advance,Food,Salary,Balance,Notes\n");
        for(int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o==null) continue;
            String[] keys={"date","place","location","start","close","hours","rate","amount","dieselL","dieselAmt","bata","advance","food","salary","balance","notes"};
            for(int j=0;j<keys.length;j++) { if(j>0) csv.append(','); csv.append('"').append(o.optString(keys[j]).replace("\"","\"\"")).append('"'); }
            csv.append('\n');
        }
        android.content.Intent send = new android.content.Intent(android.content.Intent.ACTION_SEND);
        send.setType("text/csv"); send.putExtra(android.content.Intent.EXTRA_SUBJECT, "JCB Record Book CSV");
        send.putExtra(android.content.Intent.EXTRA_TEXT, csv.toString());
        startActivity(android.content.Intent.createChooser(send, "Share CSV report"));
    }
}
